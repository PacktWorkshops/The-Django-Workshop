def average_rating(rating_list):
    return round(sum(rating_list)/len(rating_list))
