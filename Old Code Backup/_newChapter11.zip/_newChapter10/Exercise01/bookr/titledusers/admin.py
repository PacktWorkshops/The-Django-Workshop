from django.contrib import admin
from titledusers.models import TitledUser

# Register your models here.
admin.site.register(TitledUser)
