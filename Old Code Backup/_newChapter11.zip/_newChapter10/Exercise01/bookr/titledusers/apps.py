from django.apps import AppConfig


class TitledusersConfig(AppConfig):
    name = 'titledusers'
